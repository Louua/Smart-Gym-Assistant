"""Generate clean, valid kaggle_notebook.ipynb with interactive cells."""

import json
from pathlib import Path


def generate_notebook():
    cells = [
        {
            "cell_type": "markdown",
            "metadata": {},
            "source": [
                "# 🏋️ Smart Gym Assistant — Kaggle Execution Notebook\n",
                "\n",
                "**Academic Context:** Computer Engineering — *Visual Tracking & Intelligent Applications (2026-2027)*  \n",
                "**Authors:** Loua Ben Afia & Abir Rouag  \n",
                "**Supervisor:** Dr. Rihab Laajili, Polytechnic Institute  \n",
                "\n",
                "This notebook runs the complete **Smart Gym Assistant** computer vision pipeline on Kaggle GPU/CPU instances:\n",
                "1. **Pose Estimation:** MediaPipe Pose (12 core landmarks)\n",
                "2. **Temporal Tracking:** Coordinate EMA smoothing & occlusion carry-forward\n",
                "3. **Biomechanical FSM:** Finite State Machines for Squats & Bicep Curls\n",
                "4. **Video Generation:** Exports annotated MP4 video with real-time HUD overlays\n",
                "5. **Interactive Analytics:** Plotly angle trajectories, quality radar charts, and CSV/JSON export\n",
                "6. **Optional Streamlit Cloud Tunnel:** Run the full interactive web dashboard from Kaggle"
            ]
        },
        {
            "cell_type": "markdown",
            "metadata": {},
            "source": [
                "## 1. Environment Setup & Dependencies"
            ]
        },
        {
            "cell_type": "code",
            "execution_count": None,
            "metadata": {},
            "outputs": [],
            "source": [
                "# Install required pinned packages\n",
                "!pip install -q mediapipe==0.10.14 \"numpy<2.0.0\" opencv-python-headless plotly pyyaml scipy"
            ]
        },
        {
            "cell_type": "markdown",
            "metadata": {},
            "source": [
                "## 2. Verify Repository Setup & Run Unit Tests"
            ]
        },
        {
            "cell_type": "code",
            "execution_count": None,
            "metadata": {},
            "outputs": [],
            "source": [
                "import os, sys\n",
                "# If running inside cloned folder or Kaggle input, ensure root is in sys.path\n",
                "project_root = os.getcwd()\n",
                "if project_root not in sys.path:\n",
                "    sys.path.insert(0, project_root)\n",
                "\n",
                "# Run unit tests (geometry, tracker, squat FSM, curl FSM, feedback)\n",
                "!pytest -q"
            ]
        },
        {
            "cell_type": "markdown",
            "metadata": {},
            "source": [
                "## 3. Run Headless Biomechanical Pipeline on Sample Video\n",
                "\n",
                "You can specify any video from `/kaggle/input/` or the provided sample in `data/videos/squat_sample.mp4`."
            ]
        },
        {
            "cell_type": "code",
            "execution_count": None,
            "metadata": {},
            "outputs": [],
            "source": [
                "from run_kaggle import process_video_headless\n",
                "\n",
                "input_video = \"data/videos/squat_sample.mp4\"\n",
                "output_video = \"/kaggle/working/squat_annotated.mp4\" if os.path.exists(\"/kaggle\") else \"data/sessions/squat_annotated.mp4\"\n",
                "output_json = \"/kaggle/working/session.json\" if os.path.exists(\"/kaggle\") else \"data/sessions/session.json\"\n",
                "output_csv = \"/kaggle/working/reps.csv\" if os.path.exists(\"/kaggle\") else \"data/sessions/reps.csv\"\n",
                "\n",
                "session_data = process_video_headless(\n",
                "    video_path=input_video,\n",
                "    exercise_name=\"Squats\",\n",
                "    side_override=\"auto\",\n",
                "    output_video_path=output_video,\n",
                "    output_json_path=output_json,\n",
                "    output_csv_path=output_csv,\n",
                ")"
            ]
        },
        {
            "cell_type": "markdown",
            "metadata": {},
            "source": [
                "## 4. Play Annotated Video with Skeletal HUD in Notebook"
            ]
        },
        {
            "cell_type": "code",
            "execution_count": None,
            "metadata": {},
            "outputs": [],
            "source": [
                "from IPython.display import HTML\n",
                "import base64\n",
                "\n",
                "if os.path.exists(output_video):\n",
                "    with open(output_video, \"rb\") as f:\n",
                "        video_bytes = f.read()\n",
                "    encoded_video = base64.b64encode(video_bytes).decode(\"ascii\")\n",
                "    display(HTML(f'''\n",
                "        <div style=\"text-align: center;\">\n",
                "            <h3>Annotated Workout Video with Live Biomechanical HUD</h3>\n",
                "            <video width=\"640\" height=\"360\" controls autoplay muted loop>\n",
                "                <source src=\"data:video/mp4;base64,{encoded_video}\" type=\"video/mp4\">\n",
                "                Your browser does not support the video tag.\n",
                "            </video>\n",
                "        </div>\n",
                "    '''))\n",
                "else:\n",
                "    print(\"Output video file not found.\")"
            ]
        },
        {
            "cell_type": "markdown",
            "metadata": {},
            "source": [
                "## 5. Interactive Visualizations (Plotly Trajectory & Quality Radar)"
            ]
        },
        {
            "cell_type": "code",
            "execution_count": None,
            "metadata": {},
            "outputs": [],
            "source": [
                "import pandas as pd\n",
                "from app.components.charts import create_angle_trajectory_chart, create_radar_score_chart, create_gauge_chart\n",
                "from core.models import FrameResult, RepEvent\n",
                "\n",
                "# Load session result\n",
                "reps = [RepEvent(**r) for r in session_data[\"reps\"]]\n",
                "\n",
                "# Reconstruct FrameResults from processed video\n",
                "print(f\"Overall Quality Score: {session_data['summary'].get('overall_form', 0)}%\")\n",
                "fig_radar = create_radar_score_chart(session_data[\"summary\"])\n",
                "fig_radar.show()\n",
                "\n",
                "# Display per-rep table\n",
                "if os.path.exists(output_csv):\n",
                "    df_reps = pd.read_csv(output_csv)\n",
                "    display(df_reps)\n",
                "else:\n",
                "    df_reps = pd.DataFrame(session_data[\"reps\"])\n",
                "    display(df_reps)"
            ]
        },
        {
            "cell_type": "markdown",
            "metadata": {},
            "source": [
                "## 6. Run Benchmark Evaluation Suite on Kaggle\n",
                "\n",
                "Executes `evaluate.py` across the test video dataset and generates summary tables grouped by lighting, angle, and occlusion."
            ]
        },
        {
            "cell_type": "code",
            "execution_count": None,
            "metadata": {},
            "outputs": [],
            "source": [
                "!python -m evaluation.evaluate --gt evaluation/ground_truth_template.csv --videos data/videos --out evaluation/report.csv"
            ]
        },
        {
            "cell_type": "markdown",
            "metadata": {},
            "source": [
                "## 7. (Optional) Run Interactive Streamlit UI via Public Cloudflare Tunnel\n",
                "\n",
                "To use the full multi-page Streamlit web application directly from Kaggle:"
            ]
        },
        {
            "cell_type": "code",
            "execution_count": None,
            "metadata": {},
            "outputs": [],
            "source": [
                "# Launch Streamlit in the background and establish a secure public tunnel via cloudflared\n",
                "import subprocess, time\n",
                "\n",
                "print(\"Starting Streamlit...\")\n",
                "st_proc = subprocess.Popen([\"streamlit\", \"run\", \"app/Home.py\", \"--server.port=8501\", \"--server.headless=true\"])\n",
                "time.sleep(3)\n",
                "\n",
                "# Download cloudflared if not present\n",
                "if not os.path.exists(\"cloudflared\"):\n",
                "    !wget -q -nc https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64 -O cloudflared\n",
                "    !chmod +x cloudflared\n",
                "\n",
                "print(\"Launching tunnel... Click the URL printed below to open Streamlit:\")\n",
                "!./cloudflared tunnel --url http://localhost:8501"
            ]
        }
    ]

    notebook = {
        "cells": cells,
        "metadata": {
            "kernelspec": {
                "display_name": "Python 3",
                "language": "python",
                "name": "python3"
            },
            "language_info": {
                "name": "python",
                "version": "3.11.0"
            }
        },
        "nbformat": 4,
        "nbformat_minor": 2
    }

    out_path = Path("kaggle_notebook.ipynb")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(notebook, f, indent=2)

    # Also keep a copy in kaggle/
    kaggle_dir = Path("kaggle")
    kaggle_dir.mkdir(parents=True, exist_ok=True)
    with open(kaggle_dir / "smart_gym_kaggle.ipynb", "w", encoding="utf-8") as f:
        json.dump(notebook, f, indent=2)

    print(f"Generated {out_path} and {kaggle_dir / 'smart_gym_kaggle.ipynb'}")


if __name__ == "__main__":
    generate_notebook()
